﻿namespace SampleApp.Models
{
    public class Address
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public long ZipCode { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public long Mobile { get; set; }
        public string NearBy { get; set; }
    

    public List<Address> GetAddressList(long? zipCode = null, string? city = null, string? state = null)
    {
        var addressList = FetchAddressData();

        if (zipCode != null)
        {
            addressList.Where(address => address.ZipCode == zipCode).ToList();
        }
        if (state != null && city != null)
        {
            addressList.Where(address => (address.State == state) && (address.City == city)).ToList();
        }

        return addressList;
    }

    public List<Address> FetchAddressData()
    {
        var addressList = new List<Address>();

        addressList.Add(new Address()
        {
            Name = "TEMPLE VET CLINIC\r\nPO BOX 340",
            City = "LEXINGTON",
            Mobile = 5419898181,
            ZipCode = 97839,
            State = "OR",
            NearBy = "2.183 miles from 97818"
        }
       );
        addressList.Add(new Address()
        {
            Name = "COUNTRY ANIMAL HOSPITAL/KENNEL\r\nPO BOX 721",
            City = "HERMISTON",
            Mobile = 5415676086,
            ZipCode = 97838,
            State = "OR",
            NearBy = "34.068 miles from 97818"
        }
        );
        addressList.Add(new Address()
        {
            Name = "FRONTIER GENETICS VETERINARY\r\n80756 HICKEY LN",
            City = "HERMISTON",
            Mobile = 5415672930,
            ZipCode = 97838,
            State = "OR",
            NearBy = "37.143 miles from 97818"
        }
        );
        addressList.Add(new Address()
        {
            Name = "RIVERSIDE VETERINARY CLINIC\r\n2504 NE RIVERSIDE PL",
            City = "PENDLETON",
            Mobile = 5097811076,
            ZipCode = 99350,
            State = "WA",
            NearBy = "56.164 miles from 97818"
        }
        );
        addressList.Add(new Address()
        {
            Name = "MOBILE VET\r\n11512 N FRENCH RD",
            City = "PROSER",
            Mobile = 5097811076,
            ZipCode = 99350,
            State = "WA",
            NearBy = "56.164 miles from 97818"
        });
        addressList.Add(new Address()
        {
            Name = "VCA MEADOW HILLS SOUTH ANIMAL HOSPITAL 3711 PLAZA WAY",
            City = "KENNEWICK",
            Mobile = 5097350397,
            ZipCode = 99338,
            State = "WA",
            NearBy = "57.021 miles from 97818"
        });
        addressList.Add(new Address()
        {
            Name = "HORSE HAVEN HILLS PET URGENT CARE\r\n4309 W 27TH PL BLDG C STE 104",
            City = "KENNEWICK",
            Mobile = 5095810647,
            ZipCode = 99338,
            State = "WA",
            NearBy = "57.709 miles from 97818"
        });
        addressList.Add(new Address()
        {
            Name = "SUNRISE VETERINARY CLINIC\r\nPO BOX 730",
            City = "BENTON CITY",
            Mobile = 5095886970,
            ZipCode = 99320,
            State = "WA",
            NearBy = "58.839 miles from 97818"
        });
        addressList.Add(new Address()
        {
            Name = "VCA MEADOW HILLS SOUTH ANIMAL HOSPITAL 3711 PLAZA WAY",
            City = "KENNEWICK",
            Mobile = 5097350397,
            ZipCode = 99338,
            State = "WA",
            NearBy = "57.021 miles from 97818"
        });
        addressList.Add(new Address()
        {
            Name = "VCA MEADOW HILLS SOUTH ANIMAL HOSPITAL 3711 PLAZA WAY",
            City = "KENNEWICK",
            Mobile = 5097350397,
            ZipCode = 99338,
            State = "WA",
            NearBy = "57.021 miles from 97818"
        });
        addressList.Add(new Address()
        {
            Name = "VCA MEADOW HILLS SOUTH ANIMAL HOSPITAL 3711 PLAZA WAY",
            City = "KENNEWICK",
            Mobile = 5097350397,
            ZipCode = 99338,
            State = "WA",
            NearBy = "57.021 miles from 97818"
        });
        addressList.Add(new Address()
        {
            Name = "VCA MEADOW HILLS SOUTH ANIMAL HOSPITAL 3711 PLAZA WAY",
            City = "KENNEWICK",
            Mobile = 5097350397,
            ZipCode = 99338,
            State = "WA",
            NearBy = "57.021 miles from 97818"
        });
        addressList.Add(new Address()
        {
            Name = "VCA MEADOW HILLS SOUTH ANIMAL HOSPITAL 3711 PLAZA WAY",
            City = "KENNEWICK",
            Mobile = 5097350397,
            ZipCode = 99338,
            State = "WA",
            NearBy = "57.021 miles from 97818"
        });
        addressList.Add(new Address()
        {
            Name = "VCA MEADOW HILLS SOUTH ANIMAL HOSPITAL 3711 PLAZA WAY",
            City = "KENNEWICK",
            Mobile = 5097350397,
            ZipCode = 99338,
            State = "WA",
            NearBy = "57.021 miles from 97818"
        });
        addressList.Add(new Address()
        {
            Name = "VCA MEADOW HILLS SOUTH ANIMAL HOSPITAL 3711 PLAZA WAY",
            City = "KENNEWICK",
            Mobile = 5097350397,
            ZipCode = 99338,
            State = "WA",
            NearBy = "57.021 miles from 97818"
        });
        addressList.Add(new Address()
        {
            Name = "VCA MEADOW HILLS SOUTH ANIMAL HOSPITAL 3711 PLAZA WAY",
            City = "KENNEWICK",
            Mobile = 5097350397,
            ZipCode = 99338,
            State = "WA",
            NearBy = "57.021 miles from 97818"
        });
        addressList.Add(new Address()
        {
            Name = "VCA MEADOW HILLS SOUTH ANIMAL HOSPITAL 3711 PLAZA WAY",
            City = "KENNEWICK",
            Mobile = 5097350397,
            ZipCode = 99338,
            State = "WA",
            NearBy = "57.021 miles from 97818"
        });
        addressList.Add(new Address()
        {
            Name = "VCA MEADOW HILLS SOUTH ANIMAL HOSPITAL 3711 PLAZA WAY",
            City = "KENNEWICK",
            Mobile = 5097350397,
            ZipCode = 99338,
            State = "WA",
            NearBy = "57.021 miles from 97818"
        });

        return addressList;
    }
}
}
